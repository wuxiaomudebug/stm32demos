#include "user.h"

#include "oled.h"

char rx_buf[128];
extern DMA_HandleTypeDef hdma_usart1_rx;


// Global variables

void app(void){
  //OLED
  OLED_Init();
  OLED_Clear();
  OLED_Refresh();
  
  //UART
  HAL_UARTEx_ReceiveToIdle_DMA(&huart1,(uint8_t*)rx_buf,128);
  __HAL_DMA_DISABLE_IT(&hdma_usart1_rx,DMA_IT_HT);
  
  
  //TIM2 start
  HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);
  //TIM3 IC start  
  HAL_TIM_IC_Start_IT(&htim3, TIM_CHANNEL_1);
  HAL_TIM_IC_Start_IT(&htim3, TIM_CHANNEL_2);
  
  
  while(1){
    
  }
}

//uart Idle DMA
void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size){
  if(huart == &huart1){
    print("Received: %s",rx_buf);
    
    memset(rx_buf,0,128);
    HAL_UARTEx_ReceiveToIdle_DMA(&huart1,(uint8_t*)rx_buf,128);
    __HAL_DMA_DISABLE_IT(&hdma_usart1_rx,DMA_IT_HT);
  }
}

//TIM2->PWM->TIM3
void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim){
  if(htim->Channel == HAL_TIM_ACTIVE_CHANNEL_1){
      uint32_t period = HAL_TIM_ReadCapturedValue(htim,TIM_CHANNEL_1);
      uint32_t pulse = HAL_TIM_ReadCapturedValue(htim,TIM_CHANNEL_2);
      if(period != 0){
        float freq = (float)1000000/(period+1);
        float duty = (float)(pulse+1)*100 / (period+1);
        print("Freq: %.2f Hz, Duty: %.2f%%\r\n",freq,duty);
      }
  }
}


void print(const char *format, ...){
    char buf[128];
    va_list args;
    va_start(args,format);
    vsnprintf(buf,128-1,format,args);
    va_end(args);
    HAL_UART_Transmit(&huart1,(uint8_t*)buf,strlen(buf),1000);
}
