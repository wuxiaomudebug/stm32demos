#pragma once
#ifndef MAIN_H
#define MAIN_H

#include "main.h"
#include "dma.h"
#include "spi.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

#include <stdio.h>
#include <stdarg.h>
#include <string.h>

extern volatile uint32_t tim3_overflow_count;

void print(const char *format, ...);

void app(void);


#endif

